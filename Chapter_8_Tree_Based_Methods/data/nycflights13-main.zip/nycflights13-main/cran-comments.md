## R CMD check results

0 errors | 0 warnings | 1 note

* Checking installed package size:
  installed size is  6.9Mb
  sub-directories of 1Mb or more:
    data   6.9Mb

  This is a data package that will be rarely updated.

## revdepcheck results

I did not run revdeps as this patch release only exists to fix new R CMD check failures.
